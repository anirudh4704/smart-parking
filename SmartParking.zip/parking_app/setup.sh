#!/bin/bash

echo "======================================"
echo "  Smart Parking App - Auto Setup"
echo "======================================"

# ── Backend setup ──
echo ""
echo "Setting up backend..."
cd backend
python3.12 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
deactivate
cd ..

# ── Frontend setup ──
echo ""
echo "Setting up frontend..."
cd frontend
npm install
cd ..

echo ""
echo "======================================"
echo "  Setup complete!"
echo ""
echo "  To run the app:"
echo "  1. Open Terminal 1 and run:  ./start_backend.sh"
echo "  2. Open Terminal 2 and run:  ./start_frontend.sh"
echo "  3. Open browser:             http://localhost:5173"
echo "======================================"
